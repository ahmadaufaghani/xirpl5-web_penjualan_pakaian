<?php

$conn = new mysqli("localhost","root","","db_pakaian");

?>